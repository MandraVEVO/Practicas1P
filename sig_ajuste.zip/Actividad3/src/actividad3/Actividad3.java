/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad3;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author User
 */
public class Actividad3 {

    /**
     * @param args the command line arguments
     */
   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el tamano de la memoria a usar: ");
        int memoriaTotal = scanner.nextInt();

        List<Particion> particiones = new ArrayList<>();
        List<Proceso> procesos = new ArrayList<>();

        System.out.print("Ingrese el numero de particiones: ");
        int numParticiones = scanner.nextInt();

        for (int k = 0; k < numParticiones; k++) {
            System.out.print("Ingrese el tamano de la particion " + (k + 1) + ": ");
            int tamParticion = scanner.nextInt();
            particiones.add(new Particion(k + 1, tamParticion));
        }

        procesos.add(new Proceso("SISTEMA OPERATIVO", 100));  // Agregar el proceso del sistema con tamaño 100

        System.out.print("Ingrese la cantidad de procesos (sin contar el SISTEMA OPERATIVO): ");
        int numProcesos = scanner.nextInt();
        scanner.nextLine();

        for (int l = 0; l < numProcesos; l++) {
            System.out.print("Ingrese el nombre del proceso " + (l + 2) + ": ");
            String nombreProceso = scanner.nextLine();
            System.out.print("Ingrese el tamano del proceso " + (l + 2) + ": ");
            int tamProceso = scanner.nextInt();
            scanner.nextLine();
            procesos.add(new Proceso(nombreProceso, tamProceso));
        }

        particiones.get(0).ocupada = true; // Marcar la primera partición como ocupada por el sistema operativo

        int espacioOcupado = procesos.get(0).tamano; // Iniciar con el tamaño del sistema operativo

        int particionActual = 1; // Iniciar con la segunda partición
        for (int i = 1; i < procesos.size(); i++) { // Comenzar desde el segundo proceso, ya que el primero es el sistema operativo
            Proceso proceso = procesos.get(i);
            boolean asignado = false;
            for (int j = particionActual; j < particiones.size(); j++) { // Comenzar desde la partición actual
                Particion particion = particiones.get(j);
                if (!particion.ocupada && particion.tamano >= proceso.tamano) {
                    particion.tamano = proceso.tamano; // Ajustar el tamaño de la partición al tamaño del proceso
                    espacioOcupado += proceso.tamano;
                    particion.ocupada = true;
                    particionActual = j + 1; // Actualizar la partición actual para el siguiente proceso
                    System.out.println(proceso.nombre + " asignado a la particion " + particion.id);
                    asignado = true;
                    break;
                }
            }

            // Si no se asignó en una partición, buscar en las siguientes
            if (!asignado) {
                for (int j = 1; j < particiones.size(); j++) {
                    Particion particion = particiones.get(j);
                    if (!particion.ocupada && particion.tamano >= proceso.tamano) {
                        particion.tamano = proceso.tamano; // Ajustar el tamaño de la partición al tamaño del proceso
                        espacioOcupado += proceso.tamano;
                        particion.ocupada = true;
                        particionActual = j + 1; // Actualizar la partición actual para el siguiente proceso
                        System.out.println(proceso.nombre + " asignado a la particion " + particion.id);
                        break;
                    }
                }
            }
        }

        int espacioDisponible = memoriaTotal - espacioOcupado;

        // Crear una única nueva partición utilizando todo el espacio libre disponible
        if (espacioDisponible > 0) {
            Particion nuevaParticion = new Particion(particiones.size() + 1, espacioDisponible);
            particiones.add(nuevaParticion);
            System.out.println("Nueva particion creada con espacio " + espacioDisponible);
        }

        System.out.println(" ");
        System.out.println("Memoria total disponible: " + memoriaTotal);
        System.out.println("Espacio libre en memoria: " + espacioDisponible);
    }
}
    

