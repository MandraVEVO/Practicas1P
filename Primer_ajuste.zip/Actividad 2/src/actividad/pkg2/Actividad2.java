/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad.pkg2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;


/**
 *
 * @author User
 */
public class Actividad2 {

    /**
     * @param args the command line arguments
     */
      public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el tamano de la memoria a usar: ");
        int memoriaTotal = scanner.nextInt(); /*Declaracion y lectura del tamaño de memoria*/

        List<Particion> particiones = new ArrayList<>(); /*Declaracion de arreglos de particiones y procesos*/
        List<Proceso> procesos = new ArrayList<>();

        System.out.print("Ingrese el numero de particiones: ");
        int numParticiones = scanner.nextInt();  /*Declaracion y lectura de numero de particiones*/

        for (int k = 0; k < numParticiones; k++) { /*Ciclo for donde ingresa en el arreglo el numero de la particion y su tamaño*/
            System.out.print("Ingrese el tamano de la particion " + (k + 1) + ": ");
            int tamParticion = scanner.nextInt();
            particiones.add(new Particion(k + 1, tamParticion)); /*particiones.add sirve para agreagar los datos al arreglo*/
        }

        System.out.print("Ingrese la cantidad de procesos: ");
        int numProcesos = scanner.nextInt(); /*Declaracion y lectura de la cantidad de procesos*/
        scanner.nextLine(); /*salto de linea para que no se sobreescriban los datos insertados*/

        for (int l = 0; l < numProcesos; l++) { /*Ciclo for que pide el nombre y tamaño del proceso para guardarlo en el arreglo de provecesos*/
            System.out.print("Ingrese el nombre del proceso " + (l + 1) + ": ");
            String nombreProceso = scanner.nextLine();
            System.out.print("Ingrese el tamano del proceso " + (l + 1) + ": ");
            int tamProceso = scanner.nextInt();
            scanner.nextLine();
            procesos.add(new Proceso(nombreProceso, tamProceso));
        }

        int espacioOcupado = 0; /*Variable donde se guardaran la suma de los procesos*/

        for (int i = 0; i < procesos.size(); i++) { /*Ciclo for donde asignara el valor del proceso en 0*/
            Proceso proceso = procesos.get(i);
            boolean asignado = false;

            for (int j = 0; j < particiones.size(); j++) {/*for para el recorrido de la lista de particiones*/
                Particion particion = particiones.get(j);
                if (!particion.ocupada && particion.tamano >= proceso.tamano) {/*Condicional para asignar espacio de la particion*/
                    espacioOcupado += proceso.tamano;
                    particion.ocupada = true;
                    asignado = true;
                    System.out.println(proceso.nombre + " cabe en la particion " + particion.id);
                    break;
                }
            }

            if (!asignado) { /*Condicion donde el valor asinado sea diferente no cumple */
                System.out.println(proceso.nombre + " no se asigno a ninguna particion");
            }
        }

        int espacioDisponible = memoriaTotal - espacioOcupado; /*Calculo del espacio disponible restando la memoria total menos el espacio ocupado*/

       
        System.out.println("Espacio libre en memoria: " + espacioDisponible); /*Impresion de espacio disponible*/
    }
}        

      
      
        
    