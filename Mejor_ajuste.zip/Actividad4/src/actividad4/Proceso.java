/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package actividad4;

/**
 *
 * @author User
 */
public class Proceso {

        String nombre;
        int tamano;
    
    public Proceso(String nombre, int tamano){ //constructor
        this.nombre = nombre;
        this.tamano = tamano;
    }
}

