/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package actividad4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author User
 */
public class Actividad4 {

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Ingrese el tamano de la memoria a usar: ");
        int memoriaTotal = scanner.nextInt();

        List<Particion> particiones = new ArrayList<>();
        List<Proceso> procesos = new ArrayList<>();

        System.out.print("Ingrese el numero de particiones: ");
        int numParticiones = scanner.nextInt();

        for (int k = 0; k < numParticiones; k++) {
            System.out.print("Ingrese el tamano de la particion " + (k + 1) + ": ");
            int tamParticion = scanner.nextInt();
            particiones.add(new Particion(k + 1, tamParticion));
        }

        procesos.add(new Proceso("SISTEMA OPERATIVO", 100));

        System.out.print("Ingrese la cantidad de procesos (sin contar el SISTEMA OPERATIVO): ");
        int numProcesos = scanner.nextInt();
        scanner.nextLine();

        for (int l = 0; l < numProcesos; l++) {
            System.out.print("Ingrese el nombre del proceso " + (l + 2) + ": ");
            String nombreProceso = scanner.nextLine();
            System.out.print("Ingrese el tamano del proceso " + (l + 2) + ": ");
            int tamProceso = scanner.nextInt();
            scanner.nextLine();
            procesos.add(new Proceso(nombreProceso, tamProceso));
        }

        particiones.get(0).ocupada = true;
        int espacioOcupado = procesos.get(0).tamano;

        for (int i = 1; i < procesos.size(); i++) {
            Proceso proceso = procesos.get(i);
            int mejorParticionIdx = -1;
            int mejorParticionDif = Integer.MAX_VALUE;

            for (int j = 0; j < particiones.size(); j++) {
                Particion particion = particiones.get(j);
                if (!particion.ocupada && particion.tamano >= proceso.tamano) {
                    int diferencia = particion.tamano - proceso.tamano;
                    if (diferencia < mejorParticionDif) {
                        mejorParticionIdx = j;
                        mejorParticionDif = diferencia;
                    }
                }
            }

            if (mejorParticionIdx != -1) {
                Particion mejorParticion = particiones.get(mejorParticionIdx);
                mejorParticion.tamano = proceso.tamano;
                espacioOcupado += proceso.tamano;
                mejorParticion.ocupada = true;
                System.out.println(proceso.nombre + " asignado a la particion " + mejorParticion.id);
            }
        }

        int espacioDisponible = memoriaTotal - espacioOcupado;

        if (espacioDisponible > 0) {
            Particion nuevaParticion = new Particion(particiones.size() + 1, espacioDisponible);
            particiones.add(nuevaParticion);
            
        }

       
        System.out.println("Espacio libre en memoria: " + espacioDisponible);
    }
}
